import React, { useState } from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import ProductGrid from './components/ProductGrid';
import Reviews from './components/Reviews';
import Cart from './components/Cart';
import Wishlist from './components/Wishlist';
import AuthModal from './components/AuthModal';
import Footer from './components/Footer';
import { useCart } from './hooks/useCart';
import { useWishlist } from './hooks/useWishlist';
import { products } from './data/products';

function App() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  
  const {
    cartItems,
    isCartOpen,
    setIsCartOpen,
    addToCart,
    removeFromCart,
    updateQuantity,
    getTotalPrice,
    getTotalItems,
  } = useCart();

  const {
    wishlistItems,
    isWishlistOpen,
    setIsWishlistOpen,
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
  } = useWishlist();

  const handleToggleWishlist = (product: typeof products[0]) => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation
        cartCount={getTotalItems()}
        wishlistCount={wishlistItems.length}
        onCartClick={() => setIsCartOpen(true)}
        onWishlistClick={() => setIsWishlistOpen(true)}
        onAuthClick={() => setIsAuthModalOpen(true)}
      />
      
      <Hero />
      
      <ProductGrid
        products={products}
        onAddToCart={addToCart}
        onToggleWishlist={handleToggleWishlist}
        isInWishlist={isInWishlist}
      />
      
      <Reviews />
      
      <Footer />

      <Cart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeFromCart}
        totalPrice={getTotalPrice()}
      />

      <Wishlist
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistItems={wishlistItems}
        onRemoveItem={removeFromWishlist}
        onAddToCart={addToCart}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
}

export default App;