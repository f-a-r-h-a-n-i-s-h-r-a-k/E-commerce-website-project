export interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  colorImage: string;
  category: string;
  rating: number;
  reviews: number;
  description: string;
  inStock: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Review {
  id: number;
  productId: number;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  date: string;
}

export interface User {
  id: number;
  name: string;
  email: string;
  avatar?: string;
}