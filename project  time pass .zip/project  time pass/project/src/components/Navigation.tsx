import React, { useState, useEffect } from 'react';
import { ShoppingCart, Heart, User, Menu, X, Search } from 'lucide-react';

interface NavigationProps {
  cartCount: number;
  wishlistCount: number;
  onCartClick: () => void;
  onWishlistClick: () => void;
  onAuthClick: () => void;
}

const Navigation: React.FC<NavigationProps> = ({
  cartCount,
  wishlistCount,
  onCartClick,
  onWishlistClick,
  onAuthClick,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = ['Home', 'Products', 'About', 'Contact'];

  return (
    <nav
      className={`fixed top-6 left-1/2 transform -translate-x-1/2 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-black/80 backdrop-blur-md shadow-2xl'
          : 'bg-black/60 backdrop-blur-sm'
      } rounded-full px-12 py-4 border border-white/10 min-w-[800px] max-w-6xl w-[90vw]`}
    >
      <div className="flex items-center justify-between">
        {/* Logo */}
        <div className="text-white font-bold text-2xl tracking-tight">
          STORE
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-12">
          {navItems.map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              className="text-white/80 hover:text-white transition-colors duration-200 text-base font-medium"
            >
              {item}
            </a>
          ))}
        </div>

        {/* Search Bar */}
        <div className="hidden lg:flex items-center bg-white/10 rounded-full px-6 py-3 border border-white/20 min-w-[200px]">
          <Search className="w-5 h-5 text-white/60 mr-3" />
          <input
            type="text"
            placeholder="Search products..."
            className="bg-transparent text-white placeholder-white/60 text-base outline-none flex-1"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-6">
          <button
            onClick={onWishlistClick}
            className="relative p-3 text-white/80 hover:text-white transition-colors duration-200"
          >
            <Heart className="w-6 h-6" />
            {wishlistCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-white text-black text-xs rounded-full w-6 h-6 flex items-center justify-center font-medium">
                {wishlistCount}
              </span>
            )}
          </button>

          <button
            onClick={onCartClick}
            className="relative p-3 text-white/80 hover:text-white transition-colors duration-200"
          >
            <ShoppingCart className="w-6 h-6" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-white text-black text-xs rounded-full w-6 h-6 flex items-center justify-center font-medium">
                {cartCount}
              </span>
            )}
          </button>

          <button
            onClick={onAuthClick}
            className="p-3 text-white/80 hover:text-white transition-colors duration-200"
          >
            <User className="w-6 h-6" />
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-3 text-white/80 hover:text-white transition-colors duration-200"
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 mt-3 bg-black/90 backdrop-blur-md rounded-2xl p-6 border border-white/10">
          <div className="flex flex-col space-y-4">
            {navItems.map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-white/80 hover:text-white transition-colors duration-200 text-base font-medium py-3"
              >
                {item}
              </a>
            ))}
            <div className="pt-3 border-t border-white/10">
              <div className="flex items-center bg-white/10 rounded-full px-6 py-3 border border-white/20">
                <Search className="w-5 h-5 text-white/60 mr-3" />
                <input
                  type="text"
                  placeholder="Search..."
                  className="bg-transparent text-white placeholder-white/60 text-base outline-none flex-1"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navigation;