import { Review } from '../types';

export const reviews: Review[] = [
  {
    id: 1,
    productId: 1,
    userName: "Sarah Johnson",
    userAvatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop",
    rating: 5,
    comment: "Absolutely love these headphones! The sound quality is incredible and the noise cancellation works perfectly.",
    date: "2024-01-15",
  },
  {
    id: 2,
    productId: 2,
    userName: "Michael Chen",
    userAvatar: "https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop",
    rating: 5,
    comment: "This watch is exactly what I was looking for. Minimalist design and excellent build quality.",
    date: "2024-01-12",
  },
  {
    id: 3,
    productId: 3,
    userName: "Emma Davis",
    userAvatar: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop",
    rating: 4,
    comment: "Great phone with amazing camera quality. Battery life could be better but overall very satisfied.",
    date: "2024-01-10",
  },
  {
    id: 4,
    productId: 1,
    userName: "David Wilson",
    rating: 5,
    comment: "Best purchase I've made this year. The comfort and sound quality are outstanding.",
    date: "2024-01-08",
  },
  {
    id: 5,
    productId: 4,
    userName: "Lisa Rodriguez",
    userAvatar: "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop",
    rating: 5,
    comment: "These sunglasses are perfect! Great style and the UV protection gives me peace of mind.",
    date: "2024-01-05",
  },
];